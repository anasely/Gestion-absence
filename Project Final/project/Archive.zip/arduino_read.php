<?php

$serialPort = fopen("/dev/cu.usbmodem14101", "r");
set_time_limit(2);

if ($serialPort) {
  $start_time = time();
  $buffer = '';

  while (true) {
    $data = fgets($serialPort, 128);

    if ($data !== false) {
      $buffer .= $data;

      if (strpos($buffer, "\n") !== false) {
        list($cardID, $buffer) = explode("\n", $buffer, 2);

        if (strlen($cardID) === 9) {
          echo $cardID . "<br>";
          break;
        }
      }
    }

    if (time() - $start_time > 5) {
      echo "Timeout\n";
      break;
    }

    usleep(100000);
  }

  fclose($serialPort);
} else {
  echo "Failed to open serial port\n";
}
