<?php
include('db_connection.php'); // Include your database connection file

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["studentId"])) {
    $studentId = $_POST["studentId"];

    $sql = "UPDATE attendance SET status = 'Present' WHERE student_id = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("s", $studentId);

    if ($stmt->execute()) {
        echo $studentId . " student marked as present successfully.";
    } else {
        echo $studentId . "Failed to mark student as present.";
    }

    $stmt->close();
}

// ... (your other code)

// Close the database connection
$mysqli->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>for arduino</title>
</head>

<body>

    <div id="cardData"></div>

    <script>
        function fetchData() {
            fetch('arduino_read.php')
                .then(response => response.text())
                .then(data => {
                    document.getElementById('cardData').innerHTML = data.replace('<br>', '');
                    if (data) {
                        document.getElementById('studentId').value = data.replace('<br>', '');;
                        document.getElementById('formId').submit();
                    }
                })
                .catch(error => {
                    console.error('Error fetching data:', error);
                })
        }
        fetchData();
    </script>

    <form action="#" method="POST" id='formId' style="visibility: hidden;">
        <input type="text" placeholder="id" name="studentId" id="studentId"> <br>
        <input type="submit" value="Valide">
    </form>

</body>

</html>